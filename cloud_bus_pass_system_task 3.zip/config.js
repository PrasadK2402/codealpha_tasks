module.exports = {
  db: {
    host: 'localhost',
    user: 'root',
    password: 'yourpassword',
    database: 'bus_pass_system'
  }
};
