const express = require('express');
const router = express.Router();
const db = require('../db');

// Book bus pass
router.post('/book', async (req, res) => {
  const { username, busNumber, date, price } = req.body;

  if (!username || !busNumber || !date || !price || price <= 0) {
    return res.status(400).send('Invalid input or pricing');
  }

  try {
    await db.execute(
      'INSERT INTO bus_passes (username, bus_number, date, price) VALUES (?, ?, ?, ?)',
      [username, busNumber, date, price]
    );
    res.send('Bus pass booked successfully');
  } catch (err) {
    res.status(500).send('Booking failed or duplicate booking');
  }
});

// Get all bookings
router.get('/all', async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM bus_passes');
    res.json(rows);
  } catch (err) {
    res.status(500).send('Error fetching passes');
  }
});

module.exports = router;
