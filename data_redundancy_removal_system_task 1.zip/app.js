const express = require('express');
const app = express();
const dataRoutes = require('./routes/data');

app.use(express.json());
app.use('/api', dataRoutes);

app.listen(3000, () => {
  console.log('Redundancy Removal System running on port 3000');
});
