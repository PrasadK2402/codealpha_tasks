const express = require('express');
const router = express.Router();
const db = require('../db');

// Add new data if unique
router.post('/add', async (req, res) => {
  const { name, email } = req.body;

  try {
    const [existing] = await db.execute('SELECT * FROM users WHERE email = ?', [email]);
    if (existing.length > 0) {
      return res.status(409).send('Duplicate entry. Data already exists.');
    }

    await db.execute('INSERT INTO users (name, email) VALUES (?, ?)', [name, email]);
    res.send('Data added successfully (unique).');
  } catch (err) {
    res.status(500).send('Database error');
  }
});

// View all data
router.get('/all', async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM users');
    res.json(rows);
  } catch (err) {
    res.status(500).send('Error fetching data');
  }
});

module.exports = router;
