module.exports = {
  db: {
    host: 'localhost',
    user: 'root',
    password: 'yourpassword',
    database: 'redundancy_db'
  }
};
