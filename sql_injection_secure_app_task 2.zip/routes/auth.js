const express = require('express');
const router = express.Router();
const db = require('../db');
const { encrypt } = require('../utils/crypto');

// Register user (secure)
router.post('/register', async (req, res) => {
  const { username, password, capability_code } = req.body;
  if (capability_code !== 'TEST123') return res.status(403).send('Forbidden');

  const encryptedPass = encrypt(password);
  const sql = 'INSERT INTO users (username, password) VALUES (?, ?)';

  try {
    await db.execute(sql, [username, encryptedPass]);
    res.send('User registered securely');
  } catch (err) {
    res.status(500).send('Error registering user');
  }
});

// Simulated SQL injection (test-only)
router.post('/inject', async (req, res) => {
  const { injection, capability_code } = req.body;
  if (capability_code !== 'TEST123') return res.status(403).send('Unauthorized');

  const query = `SELECT * FROM users WHERE username = '${injection}'`;
  console.log('[DEBUG] SQL Injection Test:', query);
  res.send('Simulated injection logged. No execution done.');
});

module.exports = router;
