module.exports = {
  db: {
    host: 'localhost',
    user: 'root',
    password: 'yourpassword',
    database: 'secure_app'
  },
  secret: 'your_aes_256_secret_key_here_32byteslong'
};
